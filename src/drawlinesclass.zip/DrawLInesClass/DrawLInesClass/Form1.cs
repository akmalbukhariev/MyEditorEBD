﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DrawLInesClass
{
    public partial class Form1 : Form
    {
        bool _mouseDown = false, startHit = false, endHit = false, IsEdit = false;
        Point pt, pt1;
        Color lineColor;
        List<linesClass> lineCls = new List<linesClass>();
        Rectangle mouseRect;
        int lineIndex = -1;
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lineColor = Color.Black;
            rbDraw.Checked = true;
            mouseRect = new Rectangle(0,0,4,4);
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            _mouseDown = true;
            pt = e.Location;
 
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (_mouseDown == true)
            {
                label3.Text = e.Location.ToString();
                mouseRect.Location = e.Location;
                if (!IsEdit)
                {

                    this.Refresh();
                    Graphics g = this.CreateGraphics();
                    Pen myPen = new Pen(lineColor);
                    pt1 = e.Location;
                    g.DrawLine(myPen, pt, pt1);
                }
                else if (IsEdit)
                {
                    
                    if (!startHit && !endHit)
                    {
                        var b = lineCls.ElementAt(checkHit(e.Location));//get the line point to move
                    }
                    else if(startHit)//move start
                    {
                        var st = lineCls.ElementAt(lineIndex);
                        st.editStart(e.Location);                      
                        this.Refresh();
                    }
                    else if (endHit)//move end
                    {
                        var en = lineCls.ElementAt(lineIndex);
                        en.editEnd(e.Location);                      
                        this.Refresh();
                    }
                 
                }
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Default;//reset
            _mouseDown = false;//reset
            startHit = false;//reset
            endHit = false;//reset
            lineIndex = -1;//reset
            if (!IsEdit)//add new lines
            {
                lineCls.Add(new linesClass(pt, pt1, lineColor));//adds to lineClass
            }

        }


        public int  checkHit(Point p)
        {
            int i = 0;
            mouseRect.Location = p;

            foreach (linesClass lc in lineCls)
            {
                if (mouseRect.IntersectsWith(lc._startRect))
                {
                    startHit = true;
                    Cursor = Cursors.Cross;
                    break;
                

                }
                else if (mouseRect.IntersectsWith(lc._endRect))
                {
                    endHit = true;
                    Cursor = Cursors.Cross;
                    break;
                 

                }
                i += 1;
                if (i > lineCls.Count-1)
                {
                    i = lineCls.Count - 1;
                }
            }

            lineIndex = i;
            return i;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                lineColor = colorDialog1.Color;
                label2.BackColor = lineColor;
            }

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            listBox1.Items.Clear();
            foreach (linesClass lc in lineCls)//draw all lines
            {
                Pen myPen = new Pen(lc._lineColor);
                e.Graphics.DrawLine(myPen, lc._startPt, lc._endPt);
                listBox1.Items.Add(lc._startPt.ToString() + ',' + lc._endPt.ToString() + ',' + lc._lineColor.ToString());
            }
        }

        private void rbDraw_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDraw.Checked)
            {
                IsEdit = false;
            }
        }

        private void rbEdit_CheckedChanged(object sender, EventArgs e)
        {
            if (rbEdit.Checked)
            {
                IsEdit = true;
            }
        }
    }
}
