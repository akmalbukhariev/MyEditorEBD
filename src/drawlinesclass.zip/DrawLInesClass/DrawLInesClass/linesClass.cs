﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;


namespace DrawLInesClass
{
  public  class linesClass
    {
      public Point _startPt, _endPt;
        public Color _lineColor;
        public int _lineWidth;
        public Rectangle _startRect, _endRect;//use rectangle to make detection easier

        public linesClass(Point startPt, Point endPt, Color lineColor)
        {
            _startPt = startPt;
            _endPt = endPt;
        _lineColor = lineColor;
        _startRect = new Rectangle(_startPt.X, _startPt.Y, 1, 1);
        _endRect = new Rectangle(endPt.X, endPt.Y, 1, 1);

        }

        public void editStart(Point startPt)
        {
            _startPt = startPt;
            _startRect.Location = _startPt;
        }

        public void editEnd(Point endPt)
        {
            _endPt = endPt;
            _endRect.Location = _endPt;
        }
        //public bool IsInLine(Point pnt)
        //{

        //    Pen p = new Pen(Color.Red, _lineWidth);

        //    GraphicsPath pth = new GraphicsPath();

        //    pth.AddLine(_startPt, _endPt);

        //    pth.Widen(p);

        //    p.Dispose();

        //    if (pth.IsVisible(pnt))

        //        return true;

        //    return false;

        //}
    }
}
